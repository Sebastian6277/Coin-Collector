﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PlatformGame.Sprites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlatformGame.Managers
{
    public class GameManager
    {
        private readonly Map _map;
        private readonly Player _player;
        private readonly Enemies _enemies;
        private readonly SpriteFont _scoreFont;
        public GameManager(Game1 game, SpriteFont scoreFont) 
        {
            _map = new();
            _player = new(game);
            _enemies = new Enemies();
            _scoreFont = scoreFont;
        }
        public void Update()
        {
            _player.Update();
        }

        public void Draw()
        {          
            _map.Draw();
            _player.Draw();      

        }

    }
}
