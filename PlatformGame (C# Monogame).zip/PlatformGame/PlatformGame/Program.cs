﻿
using var game = new PlatformGame.Game1();
game.Run();
