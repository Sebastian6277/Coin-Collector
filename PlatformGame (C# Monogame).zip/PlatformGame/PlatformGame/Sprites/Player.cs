﻿using AdventureGame.Managers;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using PlatformGame.Managers;
using SharpDX.Direct2D1;
using System;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;

namespace PlatformGame.Sprites
{
    public class Player
    {
        private Game1 _game;

        private Texture2D player;
        public Texture2D coin;
        private SpriteFont Score;

        private const float Speed = 250f;
        private const float Gravity = 3600f;
        private const float Jump = 1000f;
        private float elapsedTimeSincePoints100 = 0f;
        private const int OffSet = 10;
        private const int CoinOffSet = 5;
        public double points = 0;
        private int RdCoinX;
        private int RdCoinY;
        private Vector2 _velocity;
        private Vector2 _position;
        public Vector2 coinPosition;
        private bool _isOnGround = true;
        public bool _hasCollided;

     

        Random random = new Random();
        Map map = new();


        public Player(Game1 game)
        {
            _game = game;
            player = Globals.Content.Load<Texture2D>("Player/Player");
            coin = Globals.Content.Load<Texture2D>("SpritesObj/GoldCoin");
            Score = Globals.Content.Load<SpriteFont>("Font/galleryFont");

            do
            {
                RdCoinX = random.Next(Globals.WindowSize.X - coin.Width);
                RdCoinY = random.Next(Globals.WindowSize.Y - coin.Height);
            } while (Map.tiles[RdCoinY / Map.TileSize, RdCoinX / Map.TileSize] != 0 || Map.tiles[RdCoinY / Map.TileSize, RdCoinX / Map.TileSize] == 4);

            _position = new Vector2(0, 350);
            coinPosition = new Vector2(RdCoinX, RdCoinY);
        }

        public Rectangle CalculateBounds(Vector2 pos)
        {
            return new((int)pos.X + OffSet, (int)pos.Y, player.Width - 2 * OffSet, player.Height);
        }
        public Rectangle CalculateCoinBounds(Vector2 pos)
        {
            return new Rectangle((int)pos.X + CoinOffSet, (int)pos.Y + CoinOffSet, coin.Width - 2 * CoinOffSet, coin.Height - 2 * CoinOffSet);
        }
        private void UpdateVelocity()
        {
            var keyboard = Keyboard.GetState();

            if (keyboard.IsKeyDown(Keys.A))
            {
                _velocity.X = -Speed;
            }
            else if (keyboard.IsKeyDown(Keys.D))
            {
                _velocity.X = Speed;
            }
            else
            {
                _velocity.X = 0;
            }
            if (!_isOnGround)
            {
                _velocity.Y += Gravity * Globals.Time;
            }
            if (keyboard.IsKeyDown(Keys.Space) && _isOnGround)
            {
                _velocity.Y = -Jump;
                _isOnGround = false;
            }
        }

        private void UpdatePosition()
        {
            _isOnGround = false;
            var newPosition = _position + _velocity * Globals.Time;
            Rectangle newRectangle = CalculateBounds(newPosition);

            foreach (var Collider in Map.GetNearestColliders(newRectangle))
            {
                if (newPosition.X != _position.X)
                {
                    newRectangle = CalculateBounds(new(newPosition.X, _position.Y));
                    if (newRectangle.Intersects(Collider))
                    {
                        if (newPosition.X > _position.X)
                        {
                            newPosition.X = Collider.Left - player.Width + OffSet;
                        }
                    }
                }

                newRectangle = CalculateBounds(new(_position.X, newPosition.Y));
                if (newRectangle.Intersects(Collider))
                {
                    if (_velocity.Y > 0)
                    {
                        newPosition.Y = Collider.Top - player.Height;
                        _isOnGround = true;
                        _velocity.Y = 0;
                    }
                    else
                    {
                        newPosition.Y = Collider.Bottom;
                        _velocity.Y = 0;
                    }
                }
            }
            newPosition.X = MathHelper.Clamp(newPosition.X, 0, Globals.WindowSize.X - player.Width);
            newPosition.Y = MathHelper.Clamp(newPosition.Y, 0, Globals.WindowSize.Y - player.Height);

            _position = newPosition;
            HandleCoinCollision();

        }
        private void HandleCoinCollision()
        {
            Rectangle playerBounds = CalculateBounds(_position);
            Rectangle coinBounds = CalculateCoinBounds(coinPosition);

            if (playerBounds.Intersects(coinBounds) && !_hasCollided)
            {
                points += 10;
                _game.timerInSeconds += 5;

                do
                {
                    RdCoinX = random.Next(Globals.WindowSize.X - coin.Width);
                    RdCoinY = random.Next(Globals.WindowSize.Y - coin.Height);
                } while (Map.tiles[RdCoinY / Map.TileSize, RdCoinX / Map.TileSize] != 0 || Map.tiles[RdCoinY / Map.TileSize, RdCoinX / Map.TileSize] == 4);

                coinPosition = new Vector2(RdCoinX, RdCoinY);
                _hasCollided = true;
            }
            else
            {
                _hasCollided = false;
            }
        }
        public void Update()
        {
            UpdateVelocity();
            UpdatePosition();

            if (points >= 100)
            {
                elapsedTimeSincePoints100 += Globals.Time;

                // Calcular la cantidad de segundos a restar basado en los puntos
                int secondsToSubtract = (int)Math.Floor((double)points / 100) * 2;

                // Restar la cantidad de segundos calculada si ha pasado 1 segundo
                if (elapsedTimeSincePoints100 >= 1f)
                {
                    _game.timerInSeconds -= secondsToSubtract;
                    elapsedTimeSincePoints100 = 0f;
                }
            }
            else
            {
                elapsedTimeSincePoints100 = 0f;
            }
        }

        public void Draw()
        {
            if (_position.Y >=448)
            {
                _game.ShowGameOverMessage();  
            }
            Globals.SpriteBatch.Draw(player, _position, Color.White);
            Globals.SpriteBatch.Draw(coin, coinPosition, Color.White);
            Globals.SpriteBatch.DrawString(Score, "SCORE: " + points, new Vector2(600, 0), Color.White);
        }
    }
}
