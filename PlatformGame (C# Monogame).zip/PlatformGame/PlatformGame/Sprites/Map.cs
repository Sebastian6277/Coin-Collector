﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PlatformGame.Managers;
using System;
using System.Collections.Generic;


namespace PlatformGame.Sprites
{
    public class Map
    {
        private readonly RenderTarget2D _target;
        public static int TileSize = 48;

        public static readonly int[,] tiles =
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
            {1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,3,1,1,1,1},
            {0,0,0,0,0,0,0,0,0,0,0,4,2,2,2,2},
            {0,0,0,0,0,0,0,0,0,0,0,4,2,2,2,2},
            {1,1,1,1,1,1,1,1,0,0,3,5,2,2,2,2},
            {2,2,2,2,2,2,2,2,0,0,4,2,2,2,2,2}
        };

        private static Rectangle[,] Colliders { get; } = new Rectangle[tiles.GetLength(0), tiles.GetLength(1)];

        public Map()
        {
            _target = new(Globals.GraphicsDevice, tiles.GetLength(1) * TileSize, tiles.GetLength(0) * TileSize);
           
            var Tile1 = Globals.Content.Load<Texture2D>("tiles/tile28");
            var Tile2 = Globals.Content.Load<Texture2D>("tiles/tile42");
            var Tile3 = Globals.Content.Load<Texture2D>("tiles/tile31");
            var Tile4 = Globals.Content.Load<Texture2D>("tiles/tile55");
            var Tile5 = Globals.Content.Load<Texture2D>("tiles/tile25");
            int tileX;
            int tileY;           

            Globals.GraphicsDevice.SetRenderTarget(_target);
            Globals.GraphicsDevice.Clear(Color.Transparent);
            Globals.SpriteBatch.Begin();

            for (tileX = 0; tileX < tiles.GetLength(0); tileX++)
            {
                for (tileY = 0; tileY < tiles.GetLength(1); tileY++)
                {

                    if (tiles[tileX, tileY] == 0) continue;
                    var posX = tileY * TileSize;
                    var posY = tileX * TileSize;
                    var tex = tiles[tileX, tileY];
                    switch (tex)
                    {
                        case 1:
                            Globals.SpriteBatch.Draw(Tile1, new Vector2(posX, posY), Color.White);
                            break;
                        case 2:
                            Globals.SpriteBatch.Draw(Tile2, new Vector2(posX, posY), Color.White);
                            break;
                        case 3:
                            Globals.SpriteBatch.Draw(Tile3, new Vector2(posX, posY), Color.White);
                            break;
                        case 4:
                            Globals.SpriteBatch.Draw(Tile4, new Vector2(posX, posY), Color.White);
                            break;
                        case 5:
                            Globals.SpriteBatch.Draw(Tile5, new Vector2(posX, posY), Color.White);
                            break;
                        default:
                            break;
                    }
                    if (tiles[tileX, tileY] > 0)
                    {
                        Rectangle collider = new Rectangle(posX, posY, TileSize, TileSize);
                        Colliders[tileX, tileY] = collider;
                    }

                }
            }
            Globals.SpriteBatch.End();
            Globals.GraphicsDevice.SetRenderTarget(null);
        }

        public static List<Rectangle> GetNearestColliders(Rectangle bounds)
        {
            int LeftTile = (int)Math.Floor((float)bounds.Left / TileSize);
            int RightTile = (int)Math.Ceiling((float)bounds.Right / TileSize) - 1;
            int TopTile = (int)Math.Floor((float)bounds.Top / TileSize);
            int BottomTile = (int)Math.Ceiling((float)bounds.Bottom / TileSize) - 1;

            LeftTile = MathHelper.Clamp(LeftTile, 0, tiles.GetLength(1));
            RightTile = MathHelper.Clamp(RightTile, 0, tiles.GetLength(1));
            TopTile = MathHelper.Clamp(TopTile, 0, tiles.GetLength(0));
            BottomTile = MathHelper.Clamp(BottomTile, 0, tiles.GetLength(0));

            List<Rectangle> result = new List<Rectangle>();

            // Verificar si el jugador ha cruzado la parte inferior del mapa
            if (bounds.Bottom > tiles.GetLength(0) * TileSize)
            {
                int additionalRows = (int)Math.Ceiling((float)(bounds.Bottom - tiles.GetLength(0) * TileSize) / TileSize);
                for (int i = 0; i < additionalRows; i++)
                {
                    int fakeRow = tiles.GetLength(0) + i;
                    for (int y = LeftTile; y <= RightTile; y++)
                    {
                        result.Add(new Rectangle(y * TileSize, fakeRow * TileSize, TileSize, TileSize));
                    }
                }
            }

            for (int x = TopTile; x <= BottomTile; x++)
            {
                for (int y = LeftTile; y <= RightTile; y++)
                {
                    if (x >= 0 && x < Colliders.GetLength(0) && y >= 0 && y < Colliders.GetLength(1))
                    {
                        if (tiles[x, y] != 0)
                        {
                            result.Add(Colliders[x, y]);
                        }
                    }
                }
            }

            return result;
        }

        public void Draw()
        {
            Globals.SpriteBatch.Draw(_target, Vector2.Zero, Color.White);
        }
    }
}
