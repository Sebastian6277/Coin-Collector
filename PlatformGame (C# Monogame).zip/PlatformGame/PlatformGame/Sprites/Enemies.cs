﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PlatformGame.Managers;

namespace PlatformGame.Sprites
{
    public class Enemies
    {
        private Texture2D enemy;
        private const int OffSet = 10;
        private Vector2 _velocity;
        public Vector2 _position;

        public Enemies()
        {
            enemy = Globals.Content.Load<Texture2D>("Enemy1/Enemy1");
            _position = new Vector2(50, 340);
        }  
        public void Update()
        {
        }

        public void Draw()
        {
            Globals.SpriteBatch.Draw(enemy, _position, Color.White);

        }
    }
}

