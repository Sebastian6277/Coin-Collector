﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace PlatformGame
{
    public class Sprite
    {
        private Texture2D Coins;
        private Vector2 _position;
        public Sprites()
        {
            Coins = Globals.Content.Load<Texture2D>("SpritesObj/GoldCoin");
            _position = new Vector2(60, 340);
        }

        private Rectangle CalculateBounds(Vector2 pos)
        {
            return new((int)pos.X + OffSet, (int)pos.Y, enemy.Width - 2 * OffSet, enemy.Height);
        }


        public void Update()
        {
        }

        public void Draw()
        {
            Globals.SpriteBatch.Draw(Coins, _position, Color.White);

        }

    }
}
