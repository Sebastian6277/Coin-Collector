﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using PlatformGame.Managers;
using PlatformGame.Sprites;
using SharpDX.DXGI;
using System;
using System.Runtime.CompilerServices;
using System.Security.Policy;

namespace PlatformGame
{
    public class Game1 : Game
    {
        private SpriteFont Score,Font;
        private Texture2D BackGround;
        public  int timerInSeconds = 60;
        public float elapsedTimeSinceDecrement = 0f;
        public float decrementInterval = 1f;
        private bool isGameOverMessageDisplayed = false;
        private readonly GraphicsDeviceManager _graphics;
        private GameManager _gameManager;
        Player _player;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            Globals.WindowSize = new(Map.tiles.GetLength(1) * Map.TileSize, Map.tiles.GetLength(0) * Map.TileSize);
            _graphics.PreferredBackBufferWidth = Globals.WindowSize.X;
            _graphics.PreferredBackBufferHeight = Globals.WindowSize.Y;
            _graphics.ApplyChanges();

            Globals.Content = Content;
            base.Initialize();
        }
        
        protected override void LoadContent()
        {
            Globals.SpriteBatch = new SpriteBatch(GraphicsDevice);
            Globals.GraphicsDevice = GraphicsDevice;
            Score = Globals.Content.Load<SpriteFont>("Font/galleryFont");
            Font = Globals.Content.Load<SpriteFont>("Font/8-BitsFont");
            BackGround = Globals.Content.Load<Texture2D>("SkyBackground");
            _player = new(this);
            _gameManager =new GameManager(this,Font);

            // TODO: use this.Content to load your game content here
        }

        public void RestartGame()
        {
            // Reiniciar las variables y el estado del juego
            timerInSeconds = 60; // O el valor inicial que desees
            elapsedTimeSinceDecrement = 0f;
            isGameOverMessageDisplayed = false;

            // Vuelve a crear instancias de los elementos del juego que necesitan reinicio
            _player = new Player(this);
            _gameManager = new GameManager(this, Font);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            elapsedTimeSinceDecrement += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (elapsedTimeSinceDecrement >= decrementInterval && timerInSeconds > 0)
            {
                timerInSeconds -= 1;
                elapsedTimeSinceDecrement = 0f;
            }

            // Verificar si la tecla E ha sido presionada y el mensaje de Game Over se ha mostrado
            if (Keyboard.GetState().IsKeyDown(Keys.E) && isGameOverMessageDisplayed)
            {
                RestartGame();
            }

            // Resto de la lógica de actualización
            Globals.Update(gameTime);
            _gameManager.Update();
            _player.Update();
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {

            GraphicsDevice.Clear(Color.CornflowerBlue);

            Globals.SpriteBatch.Begin();
            Globals.SpriteBatch.Draw(BackGround, new Vector2(0, 0), Color.White);
            
                if (timerInSeconds > 0)
            {
                _gameManager.Draw();
                Globals.SpriteBatch.DrawString(Score, "TIME: " + timerInSeconds.ToString(), new Vector2(600, 20), Color.White);
            }

            if (timerInSeconds <= 0)
            {
                ShowGameOverMessage();
            }

            Globals.SpriteBatch.End();


            base.Draw(gameTime);
        }
        public void ShowGameOverMessage()
        {
            isGameOverMessageDisplayed = true;
            timerInSeconds = 0;
            Globals.SpriteBatch.Draw(BackGround, new Vector2(0, 0), Color.White);
            Globals.SpriteBatch.DrawString(Font, "G A M E  O V E R", new Vector2(220, 90), Color.Black);
            Globals.SpriteBatch.DrawString(Font, "PRESS E TO PLAY AGAIN", new Vector2(150, 360), Color.Black);
        }
    }
}