import os
import pygame

BASE_IMG_PATH = 'Content/'

def loadImage(path):
    """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def loadImage(path)
             Method Parameters     : path
             Method return         : img
             Synopsis              : In this method we will load the images easier
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
    --------------------------------------------------------------------------------------------------------------------------------------------"""
    full_path = os.path.join(BASE_IMG_PATH, path)
    img = pygame.image.load(full_path).convert()
    img.set_colorkey((0, 0, 0))  
    return img