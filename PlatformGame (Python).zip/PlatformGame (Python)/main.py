import sys
import os
import pygame
import random
from Player import PhysicsEntity
from Sprites import loadImage
from Map import Map
from highScore import HighScore

class Game:
    
        def __init__(self):
            """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def  __init__(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will initialize the variables
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            --------------------------------------------------------------------------------------------------------------------------------------------"""
            pygame.init()      
            pygame.display.set_caption('PlatformGame')
                                                                                                    #We create our global variables  
            self.elapsedTimeSincedDecrement = 0.0
            self.timerInSeconds = 60
            self.screenHeight = 480
            self.screenWidth = 762
            self.coinHeight = 20                                                                    #Coin properties
            self.coinWidth = 20                                                                     
            self.coinX = 100
            self.coinY = 100
            self.score = 0 
            self.clock = pygame.time.Clock()
            self.isGameOverMessageDsiplayed = False
            self.screen = pygame.display.set_mode((self.screenWidth, self.screenHeight))
            
            self.movement = [False, False]
                                                                                                    #We load our assets            
            self.assets = {                                
                'player' : loadImage('Player/Player.png'),                                          #Player right
                'player_left' : loadImage('Player/Player_Left.png')}                                #Player left
            self.background = pygame.image.load('Content/SkyBackground.jpg')                        #Background
            self.coin = pygame.image.load('Content/SpritesObj/GoldCoin.png')                        #Coin asset
            self.player = PhysicsEntity(self,'player',(50,50), (32,32)) 
            self.map = Map(self.screen, pygame)
            self.highScore = HighScore()
            
            self.fontPath = os.path.join("Content/Fonts/8-bit Arcade In.ttf")                       #We load our font
            pygame.font.init()
            self.font = pygame.font.Font(self.fontPath, 30)
            self.fontColor = (255, 255, 255)
            
            
        def handleEvents(self):
            """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def handleEvents(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to get the keyboard input
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            --------------------------------------------------------------------------------------------------------------------------------------------"""
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:                                                                  #If the user press the key 
                    if event.key == pygame.K_a:                                                                     #if the user press a
                        self.movement[0] = True
                    elif event.key == pygame.K_d:                                                                   #If the user press d
                        self.movement[1] = True
                    elif event.key ==pygame.K_TAB and self.isGameOverMessageDsiplayed is True:                      #If the user press Tab and if the game over is true
                        self.highScore.showHighScores()                                                             #We show the high score table 
                    elif event.key == pygame.K_SPACE:                                                               #If the user press Space
                        if self.isGameOverMessageDsiplayed is True:                                                 #If game over is true
                            self.ResetGame()                                                                        #We reset the game 
                        else:                                                                                       #If the game over is false the player will jump
                            self.player.jump()
                elif event.type == pygame.KEYUP:                                                                    #If the user stop pressing the key 
                    if event.key == pygame.K_a:                                                                     #If the user stop pressing a 
                        self.movement[0] = False
                    elif event.key == pygame.K_d:                                                                   #If the user stop pressing d
                        self.movement[1] = False
                            
        def ShowGameOverMessage(self):
            """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def ShowGameOverMessage(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will show the game over message 
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            --------------------------------------------------------------------------------------------------------------------------------------------"""
            self.isGameOverMessageDsiplayed = True                                                                      #Game over is true 
            self.highScore.userInputText()                                                                              #Here we are going to ask for the initials 
            if self.score not in self.highScore.registeredScores:
                self.highScore.writeHighscore(self.highScore.userInput, self.score)

        def ResetGame(self):
            """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def ResetGame(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to reset the game's variables
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            --------------------------------------------------------------------------------------------------------------------------------------------"""
                                                                                                                    #Reset the game and variables
            self.player.pos[0] = 0                                                                                  #We reset the player's position 
            self.player.pos[1] = 100
            emptyPositions = self.map.getEmptyPositions() 
            if emptyPositions:
                randomPosition = random.choice(emptyPositions)                                                      #We update the coin's position 
                row, col = randomPosition                                                                           #We set the random position 
                self.coinX = col * self.map.TileSize
                self.coinY = row * self.map.TileSize
            self.timerInSeconds = 60                                                                                #We reset the time 
            self.score = 0                                                                                          #We reset the score 
            self.isGameOverMessageDsiplayed = False                                                                 #We set the game over screen false
            self.highScore.resetInput()                                                                             #We reset the input 

        def run(self):
            """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def run(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to run the game
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            --------------------------------------------------------------------------------------------------------------------------------------------"""
            while True:
                self.handleEvents()                                                                                 #We get the keyboard input 
                self.screen.blit(self.background, (0, 0))                                                           #We set the position for the background 
    
                if self.timerInSeconds <= 0:                                                                        #If the time is less or equal to 0 we shoe the game over screen
                    self.ShowGameOverMessage()
    
                if self.isGameOverMessageDsiplayed is False:                                                        #If the game over is false we run the actual game 
                                                                                                                    # We verify the collision between the player and the coin
                    if pygame.Rect(self.player.pos, self.player.size).colliderect(pygame.Rect(self.coinX, self.coinY, self.coinWidth, self.coinHeight)): #If the collision is detected
                        self.score += 10                                                                            #We add 10 to the score             
                        self.timerInSeconds +=5                                                                     #We add 5 seconds to the timer 
                        emptyPositions = self.map.getEmptyPositions()                                               #Get where the coin may and may not appear
                        if emptyPositions:
                            randomPosition = random.choice(emptyPositions)                                          #We update the coin position 
                            row, col = randomPosition
                            self.coinX = col * self.map.TileSize
                            self.coinY = row * self.map.TileSize
                            
                    self.map.draw()                                                                                 #We draw the map 
                    self.screen.blit(self.coin, (self.coinX, self.coinY))
    
                    self.player.update((self.movement[1] - self.movement[0], 0))
                    self.player.render(self.screen)

                    timerText = f"TIME: {self.timerInSeconds}"                                                      #Show remaining time
                    timerMessage = self.font.render(timerText, True, self.fontColor)
                    timerSize = timerMessage.get_rect(center=(self.screenWidth // 2, 10))
                    self.screen.blit(timerMessage, timerSize.topleft)
    
                    score_text = f"SCORE: {self.score}"                                                             #Show the score
                    score_surface = self.font.render(score_text, True, (255, 255, 255))
                    score_rect = score_surface.get_rect(center=(600, 10))
                    self.screen.blit(score_surface, score_rect.topleft)
    
                if self.isGameOverMessageDsiplayed:
                    self.ShowGameOverMessage()                                                                      #We show the Game Over message and the option to play again
    
                pygame.display.update()
                self.clock.tick(60)
    
                currentTime = pygame.time.get_ticks()
                                                                                                                    #Check if one second has passed
                if currentTime - self.elapsedTimeSincedDecrement >= 1000:
                    self.elapsedTimeSincedDecrement = currentTime
                    if not self.isGameOverMessageDsiplayed:
                        self.timerInSeconds -= 1
                    if not self.isGameOverMessageDsiplayed and self.score>=100:
                        self.timerInSeconds -=5    
        
if __name__ == "__main__":
    Game().run() 
    
    

   
