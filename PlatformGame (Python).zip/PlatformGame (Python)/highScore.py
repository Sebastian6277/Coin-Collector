import pygame 
import sys


class HighScore:
    def __init__(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def  __init__(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will initialize the variables
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        self.userInput = ""
        self.screenWidth = 762
        self.screenHeight = 480
        self.registeredScores = set()                                                                    #We use a set to avoid duplicates
        self.fontPath = "Content/Fonts/8-bit Arcade In.ttf"
        self.Font = pygame.font.Font(self.fontPath, 50)
        self.Font2 = pygame.font.Font(self.fontPath, 40)
        self.background = pygame.image.load('Content/SkyBackground.jpg')
        self.screen = pygame.display.set_mode((self.screenWidth, self.screenHeight))
        self.clock = pygame.time.Clock()

    def handleEvents(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def handleEvents(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to get the user input
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
            (Pygame documentation, 2020): https://www.pygame.org/docs/ref/event.html
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_BACKSPACE:                                                             #If the user press backspace we eliminate one char from the string
                    self.userInput = self.userInput[:-1]
                elif hasattr(event, 'unicode') and event.unicode.isalpha() and len(self.userInput) < 3:         #if the user presses a key, the initials will be written
                    self.userInput += event.unicode.upper()

    def renderTextInput(self, initials_rec):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :renderTextInput(self, initials_rec)
             Method Parameters     : self
                                   : initials_rec : this will allow us to set the initials bounds 
             Method return         : none
             Synopsis              : In this method we are going to show all the texts when the user loses
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
       
        self.screen.blit(self.background, (0, 0))                                                                  # Clear the surface
        
        gameOverSurface = self.Font.render("GAME OVER", True, (0, 0, 0))                                           #We show the game over message 
        ameOverRect = gameOverSurface.get_rect(center=(self.screenWidth // 2, 40))
        self.screen.blit(gameOverSurface, ameOverRect.topleft)
        
        InitialsSurface = self.Font.render("PLEASE ENTER YOUR INITIALS BELOW", True, (0, 0, 0))                    #We ask the user for the initials
        InitialsRect = InitialsSurface.get_rect(center=(self.screenWidth // 2, 120))
        self.screen.blit(InitialsSurface, InitialsRect.topleft)
        
        showHsTable = self.Font2.render("PRESS TAB TO DISPLAY THE SCORE TABLE", True, (0, 0, 0))                   #We tell the user that can press tab
        showHsTableRec = showHsTable.get_rect(center=(self.screenWidth // 2, 300))
        self.screen.blit(showHsTable, showHsTableRec.topleft)
        
        playAgainSurface = self.Font.render("PRESS SPACE TO PLAY AGAIN", True, (0, 0, 0))                          #We tell the user that can press Space to play again
        playAgainRect = playAgainSurface.get_rect(center=(self.screenWidth // 2, 400))
        self.screen.blit(playAgainSurface, playAgainRect.topleft)
        
        textSurface = self.Font.render(self.userInput, True, (0, 0, 0))
        textRect = textSurface.get_rect(center=(self.screenWidth // 2, 200))
        self.screen.blit(textSurface, textRect.topleft)
        
        initials_rec.w = max(100, textSurface.get_width() + 10)

    def userInputText(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :userInputText(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to display the initials 
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        initials_rec = pygame.Rect(200, 200, 0, 0)
    
        while True:
            self.handleEvents()
            self.renderTextInput(initials_rec)
            if len(self.userInput) == 3:                                                                            #Check if the user has entered three characters
                return                                                                                              #Exit the userInputText loop and reset the game
    
            pygame.display.flip()
            pygame.time.delay(30)                                                                                   #We introduce a small delay
    
    def resetInput(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :resetInput(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to reset the user's initials
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        self.userInput = ""
            
    def writeHighscore(self, initials, score):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :writeHighscore(self, initials, score)
             Method Parameters     : self, initials,score
                                   :initials: this will allow us to use the initials that we got before 
                                   : score:  This will allow us to use the score that we got before 
             Method return         : none
             Synopsis              : In this method we are going to write the user's input in the file
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        if score not in self.registeredScores:                                       #We call the update_highscores method to sort and write to the file.
            self.updateHighscores(initials, score)

    def updateHighscores(self, initials, score):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :updateHighscores(self, initials, score)
             Method Parameters     : self, initials,score
                                   :initials: this will allow us to use the initials that we got before 
                                   : score:  This will allow us to use the score that we got before 
             Method return         : none
             Synopsis              : In this method we are going to update the user's input in the file
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        try:                                                                                                  #We load existing scores from the file
            with open("highscores.txt", "r") as file:
                highScoresList = [line.strip() for line in file.readlines()]
        except FileNotFoundError:
            highScoresList = []            
        highScoresList.append(f"{initials}: {score}")                                                         #We add the new score to the list.

        highScoresList.sort(key=lambda x: int(x.split(":")[1]), reverse=True)                                 #We oder the list from highest to lowest

        highScoresList = highScoresList[:7] #We just save 7 scores
        
        with open("highscores.txt", "w") as file:                                                             #We rite the sorted list in the file
            file.write("\n".join(highScoresList))

        self.registeredScores.add(score)
            
    def showHighScores(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :showHighScores(self)
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we are going to show the highscore table
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        self.screen.blit(self.background, (0, 0))
        
        HighScoreText = self.Font.render("HIGHSCORES", True, (0, 0, 0))                                 #We write a text  to make it more comfortable
        HighScoreTextRec = HighScoreText.get_rect(center=(self.screenWidth // 2, 40))
        self.screen.blit(HighScoreText, HighScoreTextRec.topleft)
        
        highScoresList = []
        try:
            with open("highscores.txt", "r") as file:
                highScoresList = file.read().splitlines()
        except FileNotFoundError:
            highScoresList = ["High scores file not found."]
                                                                                                        #We Render and display each line on the screen
        y_position = 90 
        for score_line in highScoresList[:7]:
            highScoreSurface = self.Font.render(score_line, True, (0,0,0))
            highScoreRect = highScoreSurface.get_rect(center=(self.screenWidth // 2, y_position))
            self.screen.blit(highScoreSurface, highScoreRect.topleft)
            y_position += 40                                                                            #Line spacing
    
        pygame.display.flip()
                                                                                                        #We wait for the user to press any key to return to the game.
        waitingForKey = True
        while waitingForKey:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    waitingForKey = False
                              
if __name__ == "__main__":
    pygame.init()
    highScore = HighScore()
    highScore.userInputText()
