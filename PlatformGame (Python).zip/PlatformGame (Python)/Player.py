import pygame

class PhysicsEntity:
    def __init__(self, game, e_type, pos, size):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : def __init__(self, game, e_type, pos, size):
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will initialize the variables
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        self.game = game                                                                                    #We initialize our variables
        self.pos = list(pos)
        self.size = size
        self.velocity = [0, 0]
        self.gravity = 0.8
        self.speed = 5
        self.isJumping = False
        self.isFacingLeft = False
        self.jumpHeight = -15
        
        
        

    def jump(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : jump(self):
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will define the player's jump
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        if not self.isJumping:
            self.velocity[1] = self.jumpHeight
            self.isJumping = True

    def checkCollision(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                : checkCollision(self):
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will check the collisions 
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        playerRect = pygame.Rect(self.pos[0], self.pos[1], self.size[0], self.size[1])

        for solidRect in self.game.map.solid_rects:                                                         #Checks for collision with each solid rectangle on the map.
            if playerRect.colliderect(solidRect):
                return True                                                                                 #We return true if there's a collision

        return False
    def update(self, movement=(0, 0)):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :  update(self, movement=(0, 0)):
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we will check the collisions 
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        frameMovement = ((movement[0] * self.speed) + self.velocity[0], (movement[1] * self.speed) + self.velocity[1])
        self.velocity[1] += self.gravity
        oldPos = list(self.pos)                                                                                 #We save the position before updating

        self.pos[0] += frameMovement[0]                                                                         #We Update the position
        self.pos[1] += frameMovement[1]

        for solidRect in self.game.map.solidRects:                                                              #Collision with each rectangle on the map
            if pygame.Rect(self.pos, self.size).colliderect(solidRect):

                self.pos = oldPos                                                                               #We Restore the previous position and stop jumping
                self.velocity[1] = 0
                self.isJumping = False

        if self.pos[1] > self.game.screen.get_height() - self.size[1]:                                          #We make the player stay on the ground
            self.pos[1] = self.game.screen.get_height() - self.size[1]
            self.velocity[1] = 0
            self.isJumping = False

        if self.pos[0] < 0:                                                                                     #We make the player stay on the screen
            self.pos[0] = 0
        elif self.pos[0] > self.game.screen.get_width() - self.size[0]:
            self.pos[0] = self.game.screen.get_width() - self.size[0]

        if self.pos[1] >= 448:
            self.game.ShowGameOverMessage()

        if movement[0] < 0:                                                                                     #We Update the player's direction
            self.isFacingLeft = True
        elif movement[0] > 0:
            self.isFacingLeft = False

    def render(self, surf):
        """-------------------------------------------------------------------------------------------------------------------------------------------
             Method                :   render(self, surf):
             Method Parameters     : self
             Method return         : none
             Synopsis              : In this method we define if the player is facing left or right 
             Modifications              Author:                        Notes
                 Date:
               2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        if self.isFacingLeft:
            surf.blit(self.game.assets['player_left'], self.pos)
        else:
            surf.blit(self.game.assets['player'], self.pos)