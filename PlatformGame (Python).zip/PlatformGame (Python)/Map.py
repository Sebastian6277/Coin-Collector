import os
import pygame

BASE_IMG_PATH = 'Content/Tiles/'

class Map:
    def __init__(self, screen, pygameInstance, TileSize=48):
        """-------------------------------------------------------------------------------------------------------------------------------------------
         Method                : def  __init__(self, screen, pygameInstance, TileSize=48):
         Method Parameters     : self,screen,pygameInstance,TileSize
                               : screen: This will allow us to use the screen variable in main
                               : pygameInstance: This will allow us to load the images easier
                               : TileSize=48 : With this we set the Tile's bounds
         Method return         : none
         Synopsis              : In this method we will initialize the variables
         Modifications              Author:                        Notes
             Date:
           2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        self.TileSize = TileSize
        self.screen = screen
        self.pygame = pygameInstance
        self.tiles = [                                                                              #Here we create the map with an array 
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 2, 2, 2, 2],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 2, 2, 2, 2],
            [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 3, 5, 2, 2, 2, 2],
            [2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 4, 2, 2, 2, 2, 2]
        ]
        self.colliders = [[None] * len(row) for row in self.tiles]
        self.solidRects = []
        self.createColliders()
        self.textures = {}                                                                            #We define the textures attribute
        self.loadTextures()
    def loadTextures(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
         Method                : def loadTextures(self):
         Method Parameters     : self
         Method return         : none
         Synopsis              : In this method we load the textures 
         Modifications              Author:                        Notes
             Date:
           2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        try:
            self.textures = {
                1: pygame.image.load(os.path.join(BASE_IMG_PATH, 'grass.png')).convert_alpha(),
                2: pygame.image.load(os.path.join(BASE_IMG_PATH, 'stones.png')).convert_alpha(),
                3: pygame.image.load(os.path.join(BASE_IMG_PATH, 'leftCorner.png')).convert_alpha(),
                4: pygame.image.load(os.path.join(BASE_IMG_PATH, 'leftSide.png')).convert_alpha(),
                5: pygame.image.load(os.path.join(BASE_IMG_PATH, 'downRightCorner.png')).convert_alpha(),
            }
        except pygame.error as e:
            print("Error loading textures:", e)
    
    def getEmptyPositions(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
         Method                : def getEmptyPositions(self):
         Method Parameters     : self
         Method return         : none
         Synopsis              : In this method we define the empty positions (number 0) 
         Modifications              Author:                        Notes
             Date:
           2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        emptyPositions = []
        for row in range(len(self.tiles)):
            for col in range(len(self.tiles[row])):
                if self.tiles[row][col] == 0:
                    emptyPositions.append((row, col))
        return emptyPositions        

    def createColliders(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
         Method                : def createColliders(self):
         Method Parameters     : self
         Method return         : none
         Synopsis              : In this method we are going to create the the colliders 
         Modifications              Author:                        Notes
             Date:
           2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        for row in range(len(self.tiles)):
            for col in range(len(self.tiles[row])):
                if self.tiles[row][col] > 0:
                    x = col * self.TileSize
                    y = row * self.TileSize
                    width = self.TileSize
                    height = self.TileSize
                    self.colliders[row][col] = pygame.Rect(x, y, width, height)
                    self.solidRects.append(self.colliders[row][col])                                            #We add solid rectangle to the list

    def draw(self):
        """-------------------------------------------------------------------------------------------------------------------------------------------
         Method                : def draw(self):
         Method Parameters     : self
         Method return         : none
         Synopsis              : In this method we are going to draw the map
         Modifications              Author:                        Notes
             Date:
           2023/12/04               C.Sebastian                  Initial Setup
        --------------------------------------------------------------------------------------------------------------------------------------------"""
        for row in range(len(self.tiles)):
            for col in range(len(self.tiles[row])):
                x = col * self.TileSize
                y = row * self.TileSize
                tile_type = self.tiles[row][col]
                if tile_type > 0:
                    self.screen.blit(self.textures[tile_type], (x, y))